package com.capgemini.excercisefive;

public class Transaction extends Loan {
	private double ammount;

	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Transaction(double ammount) {
		super();
		this.ammount = ammount;
	}

	public double getAmmount() {
		return ammount;
	}

	public void setAmmount(double ammount) {
		this.ammount = ammount;
	}
	public boolean depositAmount(double amount, String AccountId,Account[] acc) {
		boolean flag=false;
		for(int i=0; i<10;i++) {
			if(AccountId.equals(acc[i].getAccountId())) {
				ammount=acc[i].getDepositeAmmount()+amount;
			acc[i].setDepositeAmmount(ammount);
			flag= true;

			}
			else {
				System.out.println("account does not exist");
				break;
			}
		}
		if(flag) {
			System.out.println("Amount deposited successfull");
			
		}
		else {
			System.out.println("transaction not initiated");
		}
		return flag;
	}
	public boolean withDraw(double amount, String accountId,Account[] acc) {
		boolean flag=false;
		for(int i=0; i<10;i++) {
			if(accountId.equals(acc[i].getAccountId())) {
				if(amount<acc[i].getDepositeAmmount()) {
				ammount=acc[i].getDepositeAmmount()-amount;
			acc[i].setDepositeAmmount(ammount);
			flag= true;

			}
				else
					System.out.println("Insufficient fund");
				break;
			}
			else {
				System.out.println("account does not exist");
				break;
			}
		}
		if(flag) {
			System.out.println("Amount withdraw successfull");
			
		}
		else {
			System.out.println("transaction not initiated");
		}
		return flag;
	}
	public boolean payLoan(double amount, String loanId, Loan[] loan) {
		boolean flag=false;
		Loan loan2= new Loan();
		for(int i=0; i<10;i++) {
			if(loanId.equals(loan[i].getLoanId())) {
				if(amount<loan[i].getLoanAmmount()) {
			double amnt=loan[i].getLoanAmmount()-amount;
			loan[i].setLoanAmmount(amnt);
			flag= true;

			}else {
				System.out.println("less loan amount");
			}
				}
			
			else {
				System.out.println("account does not exist");
				break;
			}
		}
		if(flag) {
			System.out.println("Loan Amount deposited");
		}
		else {
			System.out.println("not deposited");
		}
		return flag;
	}
	public void showAccountDetails() {
		
	}

}
